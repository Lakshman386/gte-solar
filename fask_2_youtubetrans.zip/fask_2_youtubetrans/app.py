from flask import Flask, render_template, request
from youtube_transcript_api import YouTubeTranscriptApi
from urllib.parse import urlparse, parse_qs

app = Flask(__name__)

def get_video_id(url):
    parsed_url = urlparse(url)
    if parsed_url.hostname == "youtu.be":
        return parsed_url.path[1:]
    elif parsed_url.hostname in ("www.youtube.com", "youtube.com"):
        if parsed_url.path == "/watch":
            return parse_qs(parsed_url.query).get("v", [None])[0]
        elif parsed_url.path.startswith("/embed/"):
            return parsed_url.path.split("/")[2]
    return None

def get_transcript_text_only(url):
    video_id = get_video_id(url)
    if not video_id:
        return "❌ Invalid YouTube URL."
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        full_text = " ".join([item["text"] for item in transcript])
        return full_text
    except Exception as e:
        return f"❌ Error: {e}"

@app.route('/', methods=['GET', 'POST'])
def index():
    transcript = ""
    if request.method == 'POST':
        url = request.form['youtube_url']
        transcript = get_transcript_text_only(url)
    return render_template('index.html', transcript=transcript)

if __name__ == '__main__':
    app.run(debug=True)
