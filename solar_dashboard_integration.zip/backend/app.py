
from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

# In-memory storage for simplicity
users = {}
history = []

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    email = data['email']
    password = data['password']
    
    # Simple registration logic
    if email in users:
        return jsonify({'success': False, 'message': 'User already exists.'}), 400
    users[email] = password
    return jsonify({'success': True})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data['email']
    password = data['password']
    
    # Simple login logic
    if users.get(email) == password:
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Invalid credentials.'}), 401

@app.route('/api/history', methods=['GET'])
def get_history():
    return jsonify({'success': True, 'history': history})

@app.route('/api/calculate', methods=['POST'])
def calculate():
    data = request.get_json()
    area = data['area']
    efficiency = data['efficiency']
    sunlight = data['sunlight']
    
    # Calculate solar power (kWh/day)
    irradiance = 1000  # W/m2
    power_output = (area * efficiency * irradiance * sunlight) / 1000  # in kWh
    
    # Store history
    history.append({
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'powerOutput': round(power_output, 2)
    })
    
    return jsonify({'success': True, 'powerOutput': round(power_output, 2)})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
