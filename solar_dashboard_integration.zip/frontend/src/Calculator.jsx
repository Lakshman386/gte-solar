
import React, { useState } from 'react';

const Calculator = () => {
    const [area, setArea] = useState('');
    const [efficiency, setEfficiency] = useState('');
    const [sunlight, setSunlight] = useState('');
    const [powerOutput, setPowerOutput] = useState(null);
    const [errorMessage, setErrorMessage] = useState('');

    const handleCalculate = async (e) => {
        e.preventDefault();

        // Validate inputs
        if (!area || !efficiency || !sunlight) {
            setErrorMessage('All fields are required!');
            return;
        }

        // Call Flask backend for calculation
        try {
            const response = await fetch('/api/calculate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ area, efficiency, sunlight }),
            });
            const data = await response.json();
            if (data.success) {
                setPowerOutput(data.powerOutput);
                setErrorMessage('');
            } else {
                setErrorMessage('Error during calculation.');
            }
        } catch (error) {
            setErrorMessage('An error occurred. Please try again.');
        }
    };

    return (
        <div>
            <h2>Solar Power Calculator</h2>
            <form onSubmit={handleCalculate}>
                <div>
                    <label>Roof Area (m²):</label>
                    <input
                        type="number"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Panel Efficiency (%):</label>
                    <input
                        type="number"
                        value={efficiency}
                        onChange={(e) => setEfficiency(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Sunlight Hours per Day:</label>
                    <input
                        type="number"
                        value={sunlight}
                        onChange={(e) => setSunlight(e.target.value)}
                        required
                    />
                </div>
                {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
                <button type="submit">Calculate</button>
            </form>

            {powerOutput && (
                <div>
                    <h3>Estimated Power Output: {powerOutput} kWh/day</h3>
                </div>
            )}
        </div>
    );
};

export default Calculator;
