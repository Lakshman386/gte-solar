import openai
import os
Apikey ="AIzaSyC1XZfd-JoLXrNJJd4pxIvTVOGcu51UuKc"

openai.api_key = Apikey

def generate_summary(transcript):
    prompt = f"Summarize the following YouTube transcript:\n\n{transcript}"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500
        )
        return response.choices[0].message["content"]
    except Exception as e:
        return f"Error: {e}"