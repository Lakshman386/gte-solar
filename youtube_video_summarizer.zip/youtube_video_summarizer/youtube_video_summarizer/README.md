# YouTube Video Summarizer

Summarize YouTube videos using OpenAI GPT API and Streamlit.

## Features

- Transcript extraction from YouTube
- GPT-powered summarization
- Streamlit UI
- Downloadable summaries
- View raw transcript

## Setup

```bash
cd youtube_video_summarizer
cp .env.template .env  # Add your OpenAI API key
pip install -r requirements.txt
streamlit run app.py
```